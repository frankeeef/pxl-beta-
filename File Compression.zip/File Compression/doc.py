import tkinter as tk
from tkinter import ttk
from tkinter import filedialog as fd
from tkinter.messagebox import showinfo
import compress

# create the root window
root = tk.Tk()
root.title('MZ Encrypt')
root.resizable(False, False)
root.geometry('300x150')


def select_file():
    filetypes = (
        ('All files', '*.*'),
        ('MZ files', '*.mz')
    )

    filename = fd.askopenfilename(
        title='Open a file',
        initialdir='/',
        filetypes=filetypes)

    showinfo(
        title='Encrypted File',
        message=filename
    )

    compress.Compress(filename)

def select_file_again():
    filetypes = (
        ('MZ files', '*.mz'),
        ('Encrypt files', '*.encryptedMZ')
    )

    filename = fd.askopenfilename(
        title='Open a file',
        initialdir='/',
        filetypes=filetypes)

    showinfo(
        title='Decompressed File',
        message=filename
    )

    compress.deCompress(filename)


# open button
open_button = ttk.Button(
    root,
    text='Compress to a .MZ file',
    command=select_file
)

open_button.pack(expand=True)

open_button1 = ttk.Button(
    root,
    text='Extract a .MZ File',
    command=select_file_again
)

open_button1.pack(expand=True)

root.iconbitmap("ico.ico")

# run the application
root.mainloop()
